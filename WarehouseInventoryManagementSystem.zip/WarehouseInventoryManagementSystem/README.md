# Warehouse Inventory Management System

A Java desktop application for tracking warehouse items, stock inward/outward entries, storage locations and stock reports.

## Technologies
- Java 17
- Java Swing (GUI)
- JDBC
- SQLite database
- Maven (dependency management)

## Run in VS Code
1. Install **JDK 17 or later**.
2. Install **Maven** and the **Extension Pack for Java** in VS Code.
3. Extract this ZIP file and open the `WarehouseInventoryManagementSystem` folder in VS Code.
4. Allow Maven to download the SQLite JDBC dependency (internet is required the first time).
5. Open the VS Code terminal in the project folder and run:

   ```bash
   mvn clean compile
   mvn exec:java
   ```

The database file `warehouse.db` is created automatically in the project folder when the application starts.

## Modules
1. Item Master – add, update, delete and view items.
2. Stock Inward Entry – record stock received by the warehouse.
3. Stock Outward Entry – record stock issued from the warehouse.
4. Location Tracking – manage warehouse storage locations and assign items to locations.
5. Stock Report – view current stock and export a CSV report.

## Syllabus concepts demonstrated
- Classes: `Item`, `Location`, `StockEntry`
- Inheritance: `Perishable` and `NonPerishable` extend `Item`
- Interface: `Stockable`
- Custom exception: `NegativeStockException`
- Multithreading: background low-stock alert checker
- JDBC CRUD operations using prepared statements
- Swing forms, `GridLayout`, buttons, events and tables
- File handling: export the stock report to CSV

## Notes
- Stock quantity is calculated from all inward entries minus all outward entries.
- The application prevents an outward entry that would make stock negative.
- Set a minimum stock value in Item Master. The background checker alerts when stock is at or below that level.
- The first run creates a few sample storage locations. Add your own items and stock entries.
