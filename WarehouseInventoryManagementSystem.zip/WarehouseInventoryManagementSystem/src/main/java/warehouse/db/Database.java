package warehouse.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public final class Database {
    private static Connection connection;

    private Database() {}

    public static synchronized Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection("jdbc:sqlite:warehouse.db");
            try (Statement st = connection.createStatement()) {
                st.execute("PRAGMA foreign_keys = ON");
            }
        }
        return connection;
    }

    public static void initialize() throws SQLException {
        try (Statement st = getConnection().createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS locations (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, description TEXT)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS items (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT, " +
                    "item_type TEXT NOT NULL, min_stock INTEGER NOT NULL DEFAULT 0, " +
                    "location_id INTEGER, expiry_date TEXT, " +
                    "FOREIGN KEY(location_id) REFERENCES locations(id))");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS stock_entries (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, item_id INTEGER NOT NULL, " +
                    "entry_type TEXT NOT NULL CHECK(entry_type IN ('IN','OUT')), " +
                    "quantity INTEGER NOT NULL CHECK(quantity > 0), entry_date TEXT NOT NULL, notes TEXT, " +
                    "FOREIGN KEY(item_id) REFERENCES items(id))");
        }

        try (var ps = getConnection().prepareStatement(
                "INSERT OR IGNORE INTO locations(name,description) VALUES(?,?)")) {
            String[][] defaults = {
                {"Rack A", "Main storage rack"},
                {"Rack B", "Secondary storage rack"},
                {"Cold Storage", "Temperature-controlled storage"}
            };
            for (String[] location : defaults) {
                ps.setString(1, location[0]);
                ps.setString(2, location[1]);
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }
}
