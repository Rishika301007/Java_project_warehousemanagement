package warehouse.core;

public class NegativeStockException extends Exception {
    public NegativeStockException(String message) {
        super(message);
    }
}
