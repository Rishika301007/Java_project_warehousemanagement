package warehouse.core;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract class Item implements Stockable {
    protected int id;
    protected String name;
    protected String category;
    protected int minimumStock;
    protected int locationId;

    protected Item(int id, String name, String category, int minimumStock, int locationId) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.minimumStock = minimumStock;
        this.locationId = locationId;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public int getMinimumStock() { return minimumStock; }
    public int getLocationId() { return locationId; }

    @Override
    public int getAvailableStock(Connection connection) throws SQLException {
        String sql = "SELECT COALESCE(SUM(CASE WHEN entry_type='IN' THEN quantity ELSE -quantity END),0) " +
                     "FROM stock_entries WHERE item_id=?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    public abstract String getItemType();
}
