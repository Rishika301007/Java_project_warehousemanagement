package warehouse.core;

public class StockEntry {
    private final int id;
    private final int itemId;
    private final String entryType;
    private final int quantity;
    private final String entryDate;
    private final String notes;

    public StockEntry(int id, int itemId, String entryType, int quantity, String entryDate, String notes) {
        this.id = id;
        this.itemId = itemId;
        this.entryType = entryType;
        this.quantity = quantity;
        this.entryDate = entryDate;
        this.notes = notes;
    }

    public int getId() { return id; }
    public int getItemId() { return itemId; }
    public String getEntryType() { return entryType; }
    public int getQuantity() { return quantity; }
    public String getEntryDate() { return entryDate; }
    public String getNotes() { return notes; }
}
