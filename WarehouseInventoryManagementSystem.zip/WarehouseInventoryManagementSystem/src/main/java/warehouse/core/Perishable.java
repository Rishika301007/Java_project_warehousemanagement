package warehouse.core;

public class Perishable extends Item {
    private final String expiryDate;

    public Perishable(int id, String name, String category, int minimumStock,
                      int locationId, String expiryDate) {
        super(id, name, category, minimumStock, locationId);
        this.expiryDate = expiryDate;
    }

    public String getExpiryDate() { return expiryDate; }

    @Override
    public String getItemType() { return "Perishable"; }
}
