package warehouse.core;

import java.sql.Connection;
import java.sql.SQLException;

public interface Stockable {
    int getAvailableStock(Connection connection) throws SQLException;
}
