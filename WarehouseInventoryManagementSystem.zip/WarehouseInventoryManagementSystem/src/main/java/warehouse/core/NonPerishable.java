package warehouse.core;

public class NonPerishable extends Item {
    public NonPerishable(int id, String name, String category, int minimumStock, int locationId) {
        super(id, name, category, minimumStock, locationId);
    }

    @Override
    public String getItemType() { return "Non-Perishable"; }
}
