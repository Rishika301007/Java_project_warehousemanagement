package warehouse.ui;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import warehouse.db.Database;

public class Main {
    public static void main(String[] args) {
        try {
            Database.initialize();
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
