package warehouse.ui;

import warehouse.core.NegativeStockException;
import warehouse.db.Database;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.sql.*;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

public class MainFrame extends JFrame {
    private final DefaultTableModel itemModel = model("ID", "Name", "Category", "Type", "Minimum Stock", "Location", "Expiry Date", "Available Stock");
    private final DefaultTableModel locationModel = model("ID", "Location", "Description");
    private final DefaultTableModel reportModel = model("Item ID", "Item", "Category", "Location", "Inward", "Outward", "Available", "Minimum");
    private JTable itemTable, locationTable, reportTable;
    private JTextField itemName, itemCategory, minStock, expiryDate, locationName, locationDescription, stockQuantity, stockNotes;
    private JComboBox<String> itemType;
    private JComboBox<LocationOption> itemLocation, stockItem;
    private JComboBox<String> stockType;
    private final Set<Integer> alertedItems = new HashSet<>();
    private volatile boolean running = true;

    public MainFrame() {
        setTitle("Warehouse Inventory Management System");
        setSize(1050, 700);
        setMinimumSize(new Dimension(850, 580));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JLabel heading = new JLabel("WAREHOUSE INVENTORY MANAGEMENT SYSTEM", SwingConstants.CENTER);
        heading.setFont(new Font("Arial", Font.BOLD, 21));
        heading.setBorder(BorderFactory.createEmptyBorder(18, 10, 18, 10));
        add(heading, BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Item Master", createItemPanel());
        tabs.addTab("Stock Inward / Outward", createStockPanel());
        tabs.addTab("Location Tracking", createLocationPanel());
        tabs.addTab("Stock Report", createReportPanel());
        add(tabs, BorderLayout.CENTER);

        refreshAll();
        startLowStockChecker();
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override public void windowClosing(java.awt.event.WindowEvent e) { running = false; }
        });
    }

    private static DefaultTableModel model(String... columns) {
        return new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
    }

    private JPanel createItemPanel() {
        JPanel outer = new JPanel(new BorderLayout(10, 10));
        JPanel form = new JPanel(new GridLayout(0, 4, 8, 8));
        form.setBorder(BorderFactory.createTitledBorder("Item Details"));

        itemName = new JTextField();
        itemCategory = new JTextField();
        itemType = new JComboBox<>(new String[]{"Non-Perishable", "Perishable"});
        minStock = new JTextField("5");
        expiryDate = new JTextField();
        expiryDate.setToolTipText("Use YYYY-MM-DD for perishable items");
        itemLocation = new JComboBox<>();

        addField(form, "Item Name", itemName);
        addField(form, "Category", itemCategory);
        addField(form, "Item Type", itemType);
        addField(form, "Minimum Stock", minStock);
        addField(form, "Storage Location", itemLocation);
        addField(form, "Expiry Date (optional)", expiryDate);

        JButton add = new JButton("Add Item");
        JButton update = new JButton("Update Selected");
        JButton delete = new JButton("Delete Selected");
        JButton clear = new JButton("Clear Form");
        form.add(add); form.add(update); form.add(delete); form.add(clear);

        itemTable = new JTable(itemModel);
        itemTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        itemTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && itemTable.getSelectedRow() >= 0) loadSelectedItem();
        });

        add.addActionListener(e -> saveItem(false));
        update.addActionListener(e -> saveItem(true));
        delete.addActionListener(e -> deleteSelectedItem());
        clear.addActionListener(e -> clearItemForm());

        outer.add(form, BorderLayout.NORTH);
        outer.add(new JScrollPane(itemTable), BorderLayout.CENTER);
        return outer;
    }

    private JPanel createStockPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        JPanel form = new JPanel(new GridLayout(0, 4, 8, 8));
        form.setBorder(BorderFactory.createTitledBorder("Stock Entry"));

        stockItem = new JComboBox<>();
        stockType = new JComboBox<>(new String[]{"IN", "OUT"});
        stockQuantity = new JTextField();
        stockNotes = new JTextField();

        addField(form, "Item", stockItem);
        addField(form, "Entry Type", stockType);
        addField(form, "Quantity", stockQuantity);
        addField(form, "Notes", stockNotes);

        JButton record = new JButton("Record Stock Entry");
        JButton refresh = new JButton("Refresh Items");
        form.add(record); form.add(refresh);
        record.addActionListener(e -> recordStock());
        refresh.addActionListener(e -> refreshAll());

        JTextArea help = new JTextArea(
                "IN = stock received by the warehouse. OUT = stock issued from the warehouse.\\n" +
                "The system calculates available stock as total inward minus total outward.\\n" +
                "An outward entry that would make stock negative is rejected.");
        help.setEditable(false);
        help.setBackground(panel.getBackground());
        help.setBorder(BorderFactory.createEmptyBorder(15, 12, 15, 12));

        panel.add(form, BorderLayout.NORTH);
        panel.add(help, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createLocationPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        JPanel form = new JPanel(new GridLayout(0, 4, 8, 8));
        form.setBorder(BorderFactory.createTitledBorder("Storage Location"));
        locationName = new JTextField();
        locationDescription = new JTextField();
        addField(form, "Location Name", locationName);
        addField(form, "Description", locationDescription);
        JButton add = new JButton("Add Location");
        JButton delete = new JButton("Delete Selected");
        form.add(add); form.add(delete);
        add.addActionListener(e -> addLocation());
        delete.addActionListener(e -> deleteLocation());

        locationTable = new JTable(locationModel);
        panel.add(form, BorderLayout.NORTH);
        panel.add(new JScrollPane(locationTable), BorderLayout.CENTER);
        return panel;
    }

    private JPanel createReportPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        reportTable = new JTable(reportModel);
        JButton refresh = new JButton("Refresh Report");
        JButton export = new JButton("Export CSV");
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttons.add(refresh); buttons.add(export);
        refresh.addActionListener(e -> refreshReport());
        export.addActionListener(e -> exportReport());
        panel.add(buttons, BorderLayout.NORTH);
        panel.add(new JScrollPane(reportTable), BorderLayout.CENTER);
        return panel;
    }

    private void addField(JPanel panel, String label, Component field) {
        panel.add(new JLabel(label));
        panel.add(field);
    }

    private void saveItem(boolean update) {
        try {
            String name = itemName.getText().trim();
            if (name.isEmpty()) throw new IllegalArgumentException("Enter an item name.");
            int minimum = Integer.parseInt(minStock.getText().trim());
            if (minimum < 0) throw new IllegalArgumentException("Minimum stock cannot be negative.");
            LocationOption location = (LocationOption) itemLocation.getSelectedItem();
            if (location == null) throw new IllegalArgumentException("Add/select a storage location first.");

            String type = (String) itemType.getSelectedItem();
            String expiry = expiryDate.getText().trim();
            if ("Perishable".equals(type) && expiry.isEmpty())
                throw new IllegalArgumentException("Enter an expiry date for a perishable item (YYYY-MM-DD).");

            if (update) {
                int row = itemTable.getSelectedRow();
                if (row < 0) throw new IllegalArgumentException("Select an item from the table to update.");
                int id = Integer.parseInt(itemModel.getValueAt(row, 0).toString());
                try (PreparedStatement ps = Database.getConnection().prepareStatement(
                        "UPDATE items SET name=?,category=?,item_type=?,min_stock=?,location_id=?,expiry_date=? WHERE id=?")) {
                    setItemParameters(ps, name, type, minimum, location.id, expiry);
                    ps.setInt(7, id);
                    ps.executeUpdate();
                }
            } else {
                try (PreparedStatement ps = Database.getConnection().prepareStatement(
                        "INSERT INTO items(name,category,item_type,min_stock,location_id,expiry_date) VALUES(?,?,?,?,?,?)")) {
                    setItemParameters(ps, name, type, minimum, location.id, expiry);
                    ps.executeUpdate();
                }
            }
            clearItemForm();
            refreshAll();
            JOptionPane.showMessageDialog(this, update ? "Item updated." : "Item added successfully.");
        } catch (Exception ex) { showError(ex); }
    }

    private void setItemParameters(PreparedStatement ps, String name, String type, int minimum,
                                   int locationId, String expiry) throws SQLException {
        ps.setString(1, name);
        ps.setString(2, itemCategory.getText().trim());
        ps.setString(3, type);
        ps.setInt(4, minimum);
        ps.setInt(5, locationId);
        ps.setString(6, expiry);
    }

    private void loadSelectedItem() {
        int row = itemTable.getSelectedRow();
        if (row < 0) return;
        itemName.setText(itemModel.getValueAt(row, 1).toString());
        itemCategory.setText(itemModel.getValueAt(row, 2).toString());
        itemType.setSelectedItem(itemModel.getValueAt(row, 3).toString());
        minStock.setText(itemModel.getValueAt(row, 4).toString());
        String location = itemModel.getValueAt(row, 5).toString();
        for (int i = 0; i < itemLocation.getItemCount(); i++)
            if (itemLocation.getItemAt(i).name.equals(location)) itemLocation.setSelectedIndex(i);
        expiryDate.setText(itemModel.getValueAt(row, 6).toString());
    }

    private void clearItemForm() {
        itemName.setText(""); itemCategory.setText(""); minStock.setText("5"); expiryDate.setText("");
        itemTable.clearSelection();
    }

    private void deleteSelectedItem() {
        int row = itemTable.getSelectedRow();
        if (row < 0) { showError(new Exception("Select an item to delete.")); return; }
        int id = Integer.parseInt(itemModel.getValueAt(row, 0).toString());
        if (JOptionPane.showConfirmDialog(this, "Delete this item and its stock history?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try (Connection c = Database.getConnection()) {
            c.setAutoCommit(false);
            try (PreparedStatement entries = c.prepareStatement("DELETE FROM stock_entries WHERE item_id=?");
                 PreparedStatement item = c.prepareStatement("DELETE FROM items WHERE id=?")) {
                entries.setInt(1, id); entries.executeUpdate();
                item.setInt(1, id); item.executeUpdate();
            }
            c.commit();
            refreshAll();
            clearItemForm();
        } catch (Exception ex) { showError(ex); }
    }

    private void recordStock() {
        try {
            LocationOption selected = (LocationOption) stockItem.getSelectedItem();
            if (selected == null) throw new IllegalArgumentException("Add an item first.");
            int quantity = Integer.parseInt(stockQuantity.getText().trim());
            if (quantity <= 0) throw new IllegalArgumentException("Quantity must be greater than zero.");
            String type = (String) stockType.getSelectedItem();

            int current = getStock(selected.id);
            if ("OUT".equals(type) && quantity > current)
                throw new NegativeStockException("Not enough stock. Available quantity: " + current);

            try (PreparedStatement ps = Database.getConnection().prepareStatement(
                    "INSERT INTO stock_entries(item_id,entry_type,quantity,entry_date,notes) VALUES(?,?,?,?,?)")) {
                ps.setInt(1, selected.id);
                ps.setString(2, type);
                ps.setInt(3, quantity);
                ps.setString(4, LocalDate.now().toString());
                ps.setString(5, stockNotes.getText().trim());
                ps.executeUpdate();
            }
            stockQuantity.setText(""); stockNotes.setText("");
            refreshAll();
            JOptionPane.showMessageDialog(this, "Stock " + ("IN".equals(type) ? "inward" : "outward") + " entry saved.");
        } catch (Exception ex) { showError(ex); }
    }

    private int getStock(int itemId) throws SQLException {
        try (PreparedStatement ps = Database.getConnection().prepareStatement(
                "SELECT COALESCE(SUM(CASE WHEN entry_type='IN' THEN quantity ELSE -quantity END),0) " +
                "FROM stock_entries WHERE item_id=?")) {
            ps.setInt(1, itemId);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
        }
    }

    private void addLocation() {
        try {
            String name = locationName.getText().trim();
            if (name.isEmpty()) throw new IllegalArgumentException("Enter a location name.");
            try (PreparedStatement ps = Database.getConnection().prepareStatement(
                    "INSERT INTO locations(name,description) VALUES(?,?)")) {
                ps.setString(1, name); ps.setString(2, locationDescription.getText().trim());
                ps.executeUpdate();
            }
            locationName.setText(""); locationDescription.setText("");
            refreshAll();
        } catch (Exception ex) { showError(ex); }
    }

    private void deleteLocation() {
        int row = locationTable.getSelectedRow();
        if (row < 0) { showError(new Exception("Select a location to delete.")); return; }
        int id = Integer.parseInt(locationModel.getValueAt(row, 0).toString());
        try (PreparedStatement ps = Database.getConnection().prepareStatement("DELETE FROM locations WHERE id=?")) {
            ps.setInt(1, id); ps.executeUpdate();
            refreshAll();
        } catch (Exception ex) {
            showError(new Exception("This location may be assigned to an item. Reassign the item before deleting it."));
        }
    }

    private void refreshAll() {
        refreshLocations();
        refreshItems();
        refreshStockItems();
        refreshReport();
    }

    private void refreshLocations() {
        locationModel.setRowCount(0);
        itemLocation.removeAllItems();
        try (Statement st = Database.getConnection().createStatement();
             ResultSet rs = st.executeQuery("SELECT id,name,description FROM locations ORDER BY name")) {
            while (rs.next()) {
                locationModel.addRow(new Object[]{rs.getInt(1), rs.getString(2), rs.getString(3)});
                itemLocation.addItem(new LocationOption(rs.getInt(1), rs.getString(2)));
            }
        } catch (SQLException ex) { showError(ex); }
    }

    private void refreshItems() {
        itemModel.setRowCount(0);
        String sql = "SELECT i.id,i.name,COALESCE(i.category,''),i.item_type,i.min_stock," +
                "COALESCE(l.name,''),COALESCE(i.expiry_date,'')," +
                "COALESCE((SELECT SUM(CASE WHEN s.entry_type='IN' THEN s.quantity ELSE -s.quantity END) " +
                "FROM stock_entries s WHERE s.item_id=i.id),0) " +
                "FROM items i LEFT JOIN locations l ON i.location_id=l.id ORDER BY i.name";
        try (Statement st = Database.getConnection().createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) itemModel.addRow(new Object[]{rs.getInt(1), rs.getString(2), rs.getString(3),
                    rs.getString(4), rs.getInt(5), rs.getString(6), rs.getString(7), rs.getInt(8)});
        } catch (SQLException ex) { showError(ex); }
    }

    private void refreshStockItems() {
        stockItem.removeAllItems();
        try (Statement st = Database.getConnection().createStatement();
             ResultSet rs = st.executeQuery("SELECT id,name FROM items ORDER BY name")) {
            while (rs.next()) stockItem.addItem(new LocationOption(rs.getInt(1), rs.getString(2)));
        } catch (SQLException ex) { showError(ex); }
    }

    private void refreshReport() {
        if (reportModel == null) return;
        reportModel.setRowCount(0);
        String sql = "SELECT i.id,i.name,COALESCE(i.category,''),COALESCE(l.name,'')," +
                "COALESCE(SUM(CASE WHEN s.entry_type='IN' THEN s.quantity ELSE 0 END),0)," +
                "COALESCE(SUM(CASE WHEN s.entry_type='OUT' THEN s.quantity ELSE 0 END),0)," +
                "COALESCE(SUM(CASE WHEN s.entry_type='IN' THEN s.quantity ELSE -s.quantity END),0),i.min_stock " +
                "FROM items i LEFT JOIN locations l ON i.location_id=l.id " +
                "LEFT JOIN stock_entries s ON s.item_id=i.id GROUP BY i.id ORDER BY i.name";
        try (Statement st = Database.getConnection().createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) reportModel.addRow(new Object[]{rs.getInt(1), rs.getString(2), rs.getString(3),
                    rs.getString(4), rs.getInt(5), rs.getInt(6), rs.getInt(7), rs.getInt(8)});
        } catch (SQLException ex) { showError(ex); }
    }

    private void exportReport() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("warehouse_stock_report.csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try (FileWriter writer = new FileWriter(chooser.getSelectedFile())) {
            for (int c = 0; c < reportModel.getColumnCount(); c++) {
                if (c > 0) writer.append(',');
                writer.append(csv(reportModel.getColumnName(c)));
            }
            writer.append('\n');
            for (int r = 0; r < reportModel.getRowCount(); r++) {
                for (int c = 0; c < reportModel.getColumnCount(); c++) {
                    if (c > 0) writer.append(',');
                    writer.append(csv(String.valueOf(reportModel.getValueAt(r, c))));
                }
                writer.append('\n');
            }
            JOptionPane.showMessageDialog(this, "Report exported successfully.");
        } catch (Exception ex) { showError(ex); }
    }

    private String csv(String value) { return "\"" + value.replace("\"", "\"\"") + "\""; }

    private void startLowStockChecker() {
        Thread checker = new Thread(() -> {
            while (running) {
                try {
                    Thread.sleep(60000);
                    String sql = "SELECT i.id,i.name,i.min_stock," +
                            "COALESCE((SELECT SUM(CASE WHEN entry_type='IN' THEN quantity ELSE -quantity END) " +
                            "FROM stock_entries WHERE item_id=i.id),0) AS available " +
                            "FROM items i";
                    try (Statement st = Database.getConnection().createStatement();
                         ResultSet rs = st.executeQuery(sql)) {
                        while (rs.next()) {
                            int id = rs.getInt("id");
                            if (rs.getInt("available") <= rs.getInt("min_stock") && alertedItems.add(id)) {
                                String message = rs.getString("name") + " has only " +
                                        rs.getInt("available") + " units (minimum: " + rs.getInt("min_stock") + ").";
                                SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(
                                        this, message, "Low Stock Alert", JOptionPane.WARNING_MESSAGE));
                            }
                            if (rs.getInt("available") > rs.getInt("min_stock")) alertedItems.remove(id);
                        }
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }, "LowStockAlertThread");
        checker.setDaemon(true);
        checker.start();
    }

    private void showError(Exception ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Notice", JOptionPane.ERROR_MESSAGE);
    }

    private static class LocationOption {
        final int id;
        final String name;
        LocationOption(int id, String name) { this.id = id; this.name = name; }
        @Override public String toString() { return name; }
    }
}
